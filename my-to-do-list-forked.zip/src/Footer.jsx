import React from "react"
export default function Footer(){
  return <footer><h5>Copyrights &copy; hassanoof</h5></footer>
}